import React from "react";
import styles from "./Page.module.scss";

const ExchangePage = () => {
  return (
    <div className={styles.page}>
      <div className={styles.pageContent}>
        <h1>Обмен</h1>
        <p>Страница обмена в разработке...</p>
      </div>
    </div>
  );
};

export default ExchangePage;
