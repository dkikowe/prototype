import React from "react";
import styles from "./Page.module.scss";

const LeadersPage = () => {
  return (
    <div className={styles.page}>
      <div className={styles.pageContent}>
        <div className={styles.prototypeText}>prototype</div>
      </div>
    </div>
  );
};

export default LeadersPage;
